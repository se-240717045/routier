-- =====================================================================
-- ROUTIER — Supabase veritabanı şeması
-- Supabase Dashboard → SQL Editor → bu dosyanın tamamını yapıştırıp "Run".
-- Tekrar çalıştırılabilir (idempotent) şekilde yazılmıştır.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1) PROFİLLER: auth.users ile 1-1. Giriş yöntemi ve kimlik detayları burada.
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id                uuid primary key references auth.users (id) on delete cascade,
  first_name        text,
  last_name         text,
  full_name         text,
  email             text,
  avatar_url        text,
  auth_provider     text not null default 'email',          -- ilk kayıt yöntemi: email | google | apple | anonymous
  providers         text[] not null default '{}',            -- bağlı tüm yöntemler (ör. {email,google})
  is_anonymous      boolean not null default false,
  active_vehicle_id uuid,
  settings          jsonb not null default '{}'::jsonb,      -- sesli yönlendirme, bildirim, eco varsayılan...
  locale            text not null default 'tr-TR',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  last_sign_in_at   timestamptz
);

-- ---------------------------------------------------------------------
-- 2) ARAÇLAR (Garajım)
-- ---------------------------------------------------------------------
create table if not exists public.vehicles (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references auth.users (id) on delete cascade,
  brand        text not null check (char_length(brand) between 1 and 60),
  model        text not null check (char_length(model) between 1 and 80),
  year         smallint check (year between 1950 and 2100),
  fuel_type    text not null check (fuel_type in ('Benzin', 'Dizel', 'LPG', 'Hibrit', 'Elektrik')),
  consumption  numeric(6,2) not null check (consumption > 0 and consumption < 100),  -- L veya kWh / 100 km
  fuel_price   numeric(8,2) not null check (fuel_price > 0),                         -- ₺ / L veya ₺ / kWh
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists vehicles_user_idx on public.vehicles (user_id, created_at);

-- Aktif araç silinirse profildeki referans otomatik boşalır
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'profiles_active_vehicle_fk') then
    alter table public.profiles
      add constraint profiles_active_vehicle_fk
      foreign key (active_vehicle_id) references public.vehicles (id) on delete set null;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- 3) SÜRÜŞLER (Profil istatistikleri ve aylık tasarruf)
-- ---------------------------------------------------------------------
create table if not exists public.trips (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null default auth.uid() references auth.users (id) on delete cascade,
  vehicle_id    uuid references public.vehicles (id) on delete set null,
  destination   text,
  route_type    text check (route_type in ('eco', 'fast', 'scenic')),
  distance_km   numeric(8,2) not null default 0,
  duration_min  integer not null default 0,
  fuel_amount   numeric(8,3) not null default 0,
  fuel_unit     text not null default 'L' check (fuel_unit in ('L', 'kWh')),
  cost          numeric(10,2) not null default 0,
  saved         numeric(10,2) not null default 0,
  completed     boolean not null default true,
  created_at    timestamptz not null default now()
);
create index if not exists trips_user_idx on public.trips (user_id, created_at desc);

-- ---------------------------------------------------------------------
-- 4) updated_at otomatik güncelleme
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists vehicles_updated_at on public.vehicles;
create trigger vehicles_updated_at before update on public.vehicles
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- 5) Yeni kullanıcı → profil satırı (e-posta, Google, Apple, misafir)
--    Google: full_name/name, avatar_url/picture gönderir.
--    Apple: ad-soyadı yalnızca İLK girişte gönderir; gelmezse boş kalır.
--    E-posta kaydında uygulama first_name/last_name gönderir.
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  meta  jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  app   jsonb := coalesce(new.raw_app_meta_data, '{}'::jsonb);
  prov  text  := case when coalesce(new.is_anonymous, false) then 'anonymous'
                      else coalesce(app ->> 'provider', 'email') end;
  fname text  := nullif(meta ->> 'first_name', '');
  lname text  := nullif(meta ->> 'last_name', '');
  fullname text := coalesce(nullif(meta ->> 'full_name', ''), nullif(meta ->> 'name', ''),
                          nullif(trim(concat_ws(' ', fname, lname)), ''));
begin
  if fname is null and fullname is not null then
    fname := split_part(fullname, ' ', 1);
    lname := nullif(trim(substr(fullname, length(split_part(fullname, ' ', 1)) + 1)), '');
  end if;

  insert into public.profiles (id, first_name, last_name, full_name, email, avatar_url,
                               auth_provider, providers, is_anonymous, last_sign_in_at)
  values (
    new.id, fname, lname, fullname, new.email,
    coalesce(meta ->> 'avatar_url', meta ->> 'picture'),
    prov,
    case when jsonb_typeof(app -> 'providers') = 'array' then array(select jsonb_array_elements_text(app -> 'providers')) else array[prov] end,
    coalesce(new.is_anonymous, false),
    new.last_sign_in_at
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Her girişte / hesap bağlamada: son giriş zamanı, e-posta ve bağlı yöntemleri güncelle
-- (Misafir hesap sonradan Google/Apple/e-posta ile kalıcı hesaba dönüşürse burada görünür.)
create or replace function public.handle_user_updated()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  app jsonb := coalesce(new.raw_app_meta_data, '{}'::jsonb);
begin
  update public.profiles p set
    last_sign_in_at = new.last_sign_in_at,
    email           = coalesce(new.email, p.email),
    is_anonymous    = coalesce(new.is_anonymous, false),
    providers       = case when jsonb_typeof(app -> 'providers') = 'array' then array(select jsonb_array_elements_text(app -> 'providers')) else p.providers end,
    full_name       = coalesce(p.full_name, nullif(new.raw_user_meta_data ->> 'full_name', '')),
    avatar_url      = coalesce(p.avatar_url, new.raw_user_meta_data ->> 'avatar_url', new.raw_user_meta_data ->> 'picture')
  where p.id = new.id;
  return new;
end $$;

drop trigger if exists on_auth_user_updated on auth.users;
create trigger on_auth_user_updated
  after update of last_sign_in_at, email, raw_app_meta_data, is_anonymous on auth.users
  for each row execute function public.handle_user_updated();

-- ---------------------------------------------------------------------
-- 6) SATIR DÜZEYİ GÜVENLİK: herkes yalnızca kendi verisini görür/değiştirir
-- ---------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.trips    enable row level security;

drop policy if exists "profil_okuma" on public.profiles;
create policy "profil_okuma" on public.profiles
  for select to authenticated using ((select auth.uid()) = id);

drop policy if exists "profil_guncelleme" on public.profiles;
create policy "profil_guncelleme" on public.profiles
  for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

drop policy if exists "arac_okuma" on public.vehicles;
create policy "arac_okuma" on public.vehicles
  for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "arac_ekleme" on public.vehicles;
create policy "arac_ekleme" on public.vehicles
  for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "arac_guncelleme" on public.vehicles;
create policy "arac_guncelleme" on public.vehicles
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists "arac_silme" on public.vehicles;
create policy "arac_silme" on public.vehicles
  for delete to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "surus_okuma" on public.trips;
create policy "surus_okuma" on public.trips
  for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "surus_ekleme" on public.trips;
create policy "surus_ekleme" on public.trips
  for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "surus_silme" on public.trips;
create policy "surus_silme" on public.trips
  for delete to authenticated using ((select auth.uid()) = user_id);

-- Kullanıcı başka birinin aracını aktif araç olarak atayamaz
create or replace function public.check_active_vehicle()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.active_vehicle_id is not null and not exists (
    select 1 from public.vehicles v where v.id = new.active_vehicle_id and v.user_id = new.id
  ) then
    raise exception 'active_vehicle_id bu kullanıcıya ait değil';
  end if;
  return new;
end $$;

drop trigger if exists profiles_check_active_vehicle on public.profiles;
create trigger profiles_check_active_vehicle before insert or update of active_vehicle_id on public.profiles
  for each row execute function public.check_active_vehicle();

-- Kullanıcıların kendi profil satırındaki kimlik alanlarını değiştirmesini engelle
revoke update on public.profiles from authenticated;
grant  update (first_name, last_name, full_name, avatar_url, active_vehicle_id, settings, locale)
  on public.profiles to authenticated;

-- ---------------------------------------------------------------------
-- 7) Aylık özet görünümü (Profil ekranı / ileride raporlama için)
-- ---------------------------------------------------------------------
create or replace view public.monthly_stats with (security_invoker = true) as
select
  user_id,
  date_trunc('month', created_at) as month,
  count(*)                        as trip_count,
  sum(distance_km)                as total_km,
  sum(cost)                       as total_cost,
  sum(saved)                      as total_saved
from public.trips
group by user_id, date_trunc('month', created_at);
